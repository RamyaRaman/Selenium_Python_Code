import unittest
from Package1.TC_LoginTest import LoginTest
from Package1.TC_SignUpTest import SignUpTest

from Package2.TC_PaymentTest import PaymentTest
from Package2.TC_PaymentReturn import PaymentReturnTest

#Get all tests from LoginTest, SignupTest, PaymentTest and PaymentReturnTest

tc1 = unittest.TestLoader().loadTestsFromTestCase(LoginTest)
tc2 = unittest.TestLoader().loadTestsFromTestCase(SignUpTest)
tc3 = unittest.TestLoader().loadTestsFromTestCase(PaymentTest)
tc4 = unittest.TestLoader().loadTestsFromTestCase(PaymentReturnTest)

#Creating test suites

#run only sanity test suite
sanityTestSuite = unittest.TestSuite = unittest.TestSuite([tc1,tc2]) #Sanity test suite
unittest.TextTestRunner().run(sanityTestSuite)

#run only functional test suite
functionalTestSuite = unittest.TestSuite = unittest.TestSuite([tc3,tc4]) #Sanity test suite
unittest.TextTestRunner().run(functionalTestSuite)

#run master test suite
masterTestSuite = unittest.TestSuite = unittest.TestSuite([tc1,tc2,tc3,tc4]) #Sanity test suite
unittest.TextTestRunner(verbosity=2).run(masterTestSuite)




