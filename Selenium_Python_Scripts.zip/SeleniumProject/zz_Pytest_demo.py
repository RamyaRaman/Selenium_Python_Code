import pytest

def testMethod1():
    print("This is Test method1")

def testMethod2():
    print("This is Test method2")

    # Run this test in CMD prompt