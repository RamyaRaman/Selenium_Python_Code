import pytest

@pytest.yield_fixture()
def setup():
    print("Open URL to login");
    yield
    print("Close browser after login")

def test_loginBymail(setup):
    print("this is test_loginBymail")

def test_loginByFB(setup):
    print("this is test_loginBymail")