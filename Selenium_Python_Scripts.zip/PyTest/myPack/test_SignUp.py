import pytest

@pytest.yield_fixture()
def setup():
    print("Open URL to Sign Up");
    yield
    print("Close browser after Sign Up")

def test_signUpBymail(setup):
    print("this is test_signUpBymail")

def test_signUpByFB(setup):
    print("this is test_signUpByFB")